<?php

    	
        // Append new icons
        $custom_icons = array(
            'feather-activity',
            'feather-airplay',
            'feather-alert-circle',
            'feather-alert-octagon',
            'feather-alert-triangle',
            'feather-align-center',
            'feather-align-justify',
            'feather-align-left',
            'feather-align-right',
        );

        

        // $custom_icons = array(
	       //  'angle-up',
	       //  'check',
	       //  'calendar',
	       //  'language',
	       //  'shopping-cart',
	       //  'bars',
	       //  'search',
	       //  'map-marker',
	       //  'arrow-right',
	       //  'arrow-left',
	       //  'arrow-up',
	       //  'arrow-down',
	       //  'angle-right',
	       //  'angle-left',
	       //  'angle-up',
	       //  'angle-down',
	       //  'phone',
	       //  'users',
	       //  'user',
	       //  'map-marked-alt',
	       //  'trophy-alt',
	       //  'envelope',
	       //  'marker',
	       //  'globe',
	       //  'broom',
	       //  'home',
	       //  'bed',
	       //  'chair',
	       //  'bath',
	       //  'tree',
	       //  'laptop-code',
	       //  'cube',
	       //  'cog',
	       //  'play',
	       //  'trophy-alt',
	       //  'heart',
	       //  'truck',
	       //  'user-circle',
	       //  'map-marker-alt',
	       //  'comments'
        // );    

        return $custom_icons;

        

        